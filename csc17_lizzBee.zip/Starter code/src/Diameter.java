import java.util.*;

public class Diameter {
	// place your code here

	public Diameter(Graph g) {
		// place your code here
	}

	public int getDiameter() {
		// place your code here
		return 0;
	}
}
